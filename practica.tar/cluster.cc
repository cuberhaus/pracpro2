#include "BinTree.hh"
#include "cluster.hh"


cluster::cluster() {
}

//cluster::cluster(const double dist, const string id) {
//}

/*cluster::obtener_distancia() { 
    assert(dist >= 0);
    return dist;
}

cluster::obtener_cluster() {
    return bindist;
}
*/
